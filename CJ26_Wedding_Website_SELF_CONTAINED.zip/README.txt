CJ26 self-contained wedding website. All six designs are embedded inside index.html, so no assets folder is required. Open index.html in a browser, or upload index.html to a web host.
